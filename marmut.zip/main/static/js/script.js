// static/js/script.js
window.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
        document.querySelector("h1").style.opacity = "1";
        document.querySelector("h5").style.opacity = "1";
        document.querySelector("p").style.opacity = "1";
    }, 1000);
});
